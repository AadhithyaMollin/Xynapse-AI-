# Frozen Xynapse AI model bundle

Predictions are computational hypotheses, not experimental findings.

ESM model: `facebook/esm2_t12_35M_UR50D` (`esm2_t12_35M`). The production function estimator and selected isotonic calibrator are bundled in `function_tier1.joblib`; the standalone selected calibrator is `function_calibrator_tier1.joblib`. In this frozen inventory, `function_logistic_tier1.joblib` is an auxiliary logistic-regression feature baseline. Verify against `MODEL_BUNDLE_MANIFEST.json` and `FROZEN.json` before loading.
