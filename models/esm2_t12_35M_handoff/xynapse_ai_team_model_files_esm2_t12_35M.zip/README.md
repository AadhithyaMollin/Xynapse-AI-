# Teammate model files

Predictions are computational hypotheses, not experimental findings.

This handoff contains the requested `stability_tier1.joblib`, `function_tier1.joblib`, and `function_logistic_tier1.joblib`. The third file is a Platt/logistic probability calibrator fit from saved grouped OOF predictions. It is an alternative: production inference selects isotonic calibration, already embedded in `function_tier1.joblib`. The canonical frozen `function_logistic_tier1.joblib` in the model directory is a separate logistic-regression feature baseline. Do not overwrite it or merge this handoff directory into the canonical model directory. See `TEAM_HANDOFF_MANIFEST.json` for hashes and roles.
